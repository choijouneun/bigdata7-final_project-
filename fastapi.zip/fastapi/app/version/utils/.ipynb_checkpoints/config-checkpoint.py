def aws_config():
    aws_access_key_id = "AKIAWZMQVI3Z3OR5Z6FY"
    aws_secret_access_key = "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"
    return aws_access_key_id, aws_secret_access_key

def openai():
    openai_key = "sk-proj-3JUo4EwKOKPcoterMJVST3BlbkFJlrgUmwrvlEKN9Nlv3uik"
    return openai_key